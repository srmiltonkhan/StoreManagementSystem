<?php
	echo "Welcome to KYAU";
?>
<head>
  <link href="vendor/fontawesome/css/all.css" rel="stylesheet"> <!--load all styles -->
  <link href="vendor/fontawesome/css/fontawesome.css" rel="stylesheet"> <!--load all styles -->
  <link href="vendor/fontawesome/css/brands.css" rel="stylesheet"> <!--load all styles -->
  <link href="vendor/fontawesome/css/brands.css" rel="stylesheet"> <!--load all styles -->
</head>
<body>
  <i class="fas fa-user fa-lg"></i> <!-- uses solid style -->
  <i class="far fa-user-tie"></i> <!-- uses regular style -->
  <i class="fal fa-user"></i> <!-- uses light style -->
  <!--brand icon-->
  <i class="fab fa-github-square"></i> <!-- uses brands style -->
</body>