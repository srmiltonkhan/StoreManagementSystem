<?php
    // Brand Name
    $brand_name = "STORE MANAGEMENT SYSTEM";
    // Header Marquee Title
    $header_mqrquee_title = "WELCOME TO KYAU STORE MANAGEMENT SYSTEM";
    $profile_name = "Milton Hossain";
        $my_profile = "My Profile";
        $change_password = "Change Password";
        $logout = "Logout";

    // Side Navbar Items Name
    $dashboard = "Dashboard";
    $mis = "MIS";
        $stock_report = "Stock Report";
        $issued_report = "Issued Report";
        $return_scrap_report = "Return/Scrap Report";
    $inventory = "Inventory";
        $category = "Category";
        $brand = "Brand";
        $product = "Product";
    $warehouse = "Warehouse";
        $stock_info = "Stock Information";
        $warehouse_cost_information = "Cost Information";
    $inventory_requisition = "Inventory Requisition";
    $requisition_inventory = "Requisition Inventory";
        $department_office = "Department / Office";
        $registrar = "Registrar";
        $vice_chancellor = "Vice Chancellor";
        $store_manager = "Store Manager";
    $issued_inventory = "Issued Inventory";
    $return_scrap_inventory = "Return/Scrap Inventory";
    $member = "Member";
    $user_control = "User Control";
    $user_login_activity = "User Login Activity";
    $access_control = "Access Control";
    // Footer Policy Name
    $footer_policy_name = "Copyright &copy "."2020"."-".Date("Y")." All Rights Reserved by KYAU";
    // Developer & Designer Name
    $developer_and_designer_name = "KYAU IT DEPARTMENT";
?>